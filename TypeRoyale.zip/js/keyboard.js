let aA = document.querySelector("#aA");

window.addEventListener("keydown", function (event) {
  if (event.keyCode === 65) {
    aA.className = "key-pressed";
  }
});

window.addEventListener("keyup", function (event) {
  if (event.keyCode === 65) {
    aA.className = "key";
  }
});

let bB = document.querySelector("#bB");

window.addEventListener("keydown", function (event) {
  if (event.keyCode === 66) {
    bB.className = "key-pressed";
  }
});

window.addEventListener("keyup", function (event) {
  if (event.keyCode === 66) {
    bB.className = "key";
  }
});

let cC = document.querySelector("#cC");

window.addEventListener("keydown", function (event) {
  if (event.keyCode === 67) {
    cC.className = "key-pressed";
  }
});

window.addEventListener("keyup", function (event) {
  if (event.keyCode === 67) {
    cC.className = "key";
  }
});

let dD = document.querySelector("#dD");

window.addEventListener("keydown", function (event) {
  if (event.keyCode === 68) {
    dD.className = "key-pressed";
  }
});

window.addEventListener("keyup", function (event) {
  if (event.keyCode === 68) {
    dD.className = "key";
  }
});

let eE = document.querySelector("#eE");

window.addEventListener("keydown", function (event) {
  if (event.keyCode === 69) {
    eE.className = "key-pressed";
  }
});

window.addEventListener("keyup", function (event) {
  if (event.keyCode === 69) {
    eE.className = "key";
  }
});

let fF = document.querySelector("#fF");

window.addEventListener("keydown", function (event) {
  if (event.keyCode === 70) {
    fF.className = "key-pressed";
  }
});

window.addEventListener("keyup", function (event) {
  if (event.keyCode === 70) {
    fF.className = "key";
  }
});

let gG = document.querySelector("#gG");

window.addEventListener("keydown", function (event) {
  if (event.keyCode === 71) {
    gG.className = "key-pressed";
  }
});

window.addEventListener("keyup", function (event) {
  if (event.keyCode === 71) {
    gG.className = "key";
  }
});

let hH = document.querySelector("#hH");

window.addEventListener("keydown", function (event) {
  if (event.keyCode === 72) {
    hH.className = "key-pressed";
  }
});

window.addEventListener("keyup", function (event) {
  if (event.keyCode === 72) {
    hH.className = "key";
  }
});

let iI = document.querySelector("#iI");

window.addEventListener("keydown", function (event) {
  if (event.keyCode === 73) {
    iI.className = "key-pressed";
  }
});

window.addEventListener("keyup", function (event) {
  if (event.keyCode === 73) {
    iI.className = "key";
  }
});

let jJ = document.querySelector("#jJ");

window.addEventListener("keydown", function (event) {
  if (event.keyCode === 74) {
    jJ.className = "key-pressed";
  }
});

window.addEventListener("keyup", function (event) {
  if (event.keyCode === 74) {
    jJ.className = "key";
  }
});

let kK = document.querySelector("#kK");

window.addEventListener("keydown", function (event) {
  if (event.keyCode === 75) {
    kK.className = "key-pressed";
  }
});

window.addEventListener("keyup", function (event) {
  if (event.keyCode === 75) {
    kK.className = "key";
  }
});

let lL = document.querySelector("#lL");

window.addEventListener("keydown", function (event) {
  if (event.keyCode === 76) {
    lL.className = "key-pressed";
  }
});

window.addEventListener("keyup", function (event) {
  if (event.keyCode === 76) {
    lL.className = "key";
  }
});

let mM = document.querySelector("#mM");

window.addEventListener("keydown", function (event) {
  if (event.keyCode === 77) {
    mM.className = "key-pressed";
  }
});

window.addEventListener("keyup", function (event) {
  if (event.keyCode === 77) {
    mM.className = "key";
  }
});

let nN = document.querySelector("#nN");

window.addEventListener("keydown", function (event) {
  if (event.keyCode === 78) {
    nN.className = "key-pressed";
  }
});

window.addEventListener("keyup", function (event) {
  if (event.keyCode === 78) {
    nN.className = "key";
  }
});

let oO = document.querySelector("#oO");

window.addEventListener("keydown", function (event) {
  if (event.keyCode === 79) {
    oO.className = "key-pressed";
  }
});

window.addEventListener("keyup", function (event) {
  if (event.keyCode === 79) {
    oO.className = "key";
  }
});

let pP = document.querySelector("#pP");

window.addEventListener("keydown", function (event) {
  if (event.keyCode === 80) {
    pP.className = "key-pressed";
  }
});

window.addEventListener("keyup", function (event) {
  if (event.keyCode === 80) {
    pP.className = "key";
  }
});

let qQ = document.querySelector("#qQ");

window.addEventListener("keydown", function (event) {
  if (event.keyCode === 81) {
    qQ.className = "key-pressed";
  }
});

window.addEventListener("keyup", function (event) {
  if (event.keyCode === 81) {
    qQ.className = "key";
  }
});

let rR = document.querySelector("#rR");

window.addEventListener("keydown", function (event) {
  if (event.keyCode === 82) {
    rR.className = "key-pressed";
  }
});

window.addEventListener("keyup", function (event) {
  if (event.keyCode === 82) {
    rR.className = "key";
  }
});

let sS = document.querySelector("#sS");

window.addEventListener("keydown", function (event) {
  if (event.keyCode === 83) {
    sS.className = "key-pressed";
  }
});

window.addEventListener("keyup", function (event) {
  if (event.keyCode === 83) {
    sS.className = "key";
  }
});

let tT = document.querySelector("#tT");

window.addEventListener("keydown", function (event) {
  if (event.keyCode === 84) {
    tT.className = "key-pressed";
  }
});

window.addEventListener("keyup", function (event) {
  if (event.keyCode === 84) {
    tT.className = "key";
  }
});

let uU = document.querySelector("#uU");

window.addEventListener("keydown", function (event) {
  if (event.keyCode === 85) {
    uU.className = "key-pressed";
  }
});

window.addEventListener("keyup", function (event) {
  if (event.keyCode === 85) {
    uU.className = "key";
  }
});

let vV = document.querySelector("#vV");

window.addEventListener("keydown", function (event) {
  if (event.keyCode === 86) {
    vV.className = "key-pressed";
  }
});

window.addEventListener("keyup", function (event) {
  if (event.keyCode === 86) {
    vV.className = "key";
  }
});

let wW = document.querySelector("#wW");

window.addEventListener("keydown", function (event) {
  if (event.keyCode === 87) {
    wW.className = "key-pressed";
  }
});

window.addEventListener("keyup", function (event) {
  if (event.keyCode === 87) {
    wW.className = "key";
  }
});

let xX = document.querySelector("#xX");

window.addEventListener("keydown", function (event) {
  if (event.keyCode === 88) {
    xX.className = "key-pressed";
  }
});

window.addEventListener("keyup", function (event) {
  if (event.keyCode === 88) {
    xX.className = "key";
  }
});

let yY = document.querySelector("#yY");

window.addEventListener("keydown", function (event) {
  if (event.keyCode === 89) {
    yY.className = "key-pressed";
  }
});

window.addEventListener("keyup", function (event) {
  if (event.keyCode === 89) {
    yY.className = "key";
  }
});

let zZ = document.querySelector("#zZ");

window.addEventListener("keydown", function (event) {
  if (event.keyCode === 90) {
    zZ.className = "key-pressed";
  }
});

window.addEventListener("keyup", function (event) {
  if (event.keyCode === 90) {
    zZ.className = "key";
  }
});

let dot = document.querySelector("#dot");

window.addEventListener("keydown", function (event) {
    if (event.keyCode === 190) {
      dot.className = "key-pressed";
    }
  });
  
  window.addEventListener("keyup", function (event) {
    if (event.keyCode === 190) {
      dot.className = "key";
    }
  });
  
let comma = document.querySelector("#comma");

window.addEventListener("keydown", function (event) {
    if (event.keyCode === 188) {
      comma.className = "key-pressed";
    }
  });
  
  window.addEventListener("keyup", function (event) {
    if (event.keyCode === 188) {
      comma.className = "key";
    }
  });
  
let semicolon = document.querySelector("#semicolon");

window.addEventListener("keydown", function (event) {
    if (event.keyCode === 186) {
      semicolon.className = "key-pressed";
    }
  });
  
  window.addEventListener("keyup", function (event) {
    if (event.keyCode === 186) {
      semicolon.className = "key";
    }
  });
  
let backspace = document.querySelector("#backspace");

window.addEventListener("keydown", function (event) {
    if (event.keyCode === 8) {
      backspace.className = "key-pressed";
    }
  });
  
  window.addEventListener("keyup", function (event) {
    if (event.keyCode === 8) {
      backspace.className = "key";
    }
  });
  
 
let spacebar = document.querySelector("#spacebar");

window.addEventListener("keydown", function (event) {
    if (event.keyCode === 32) {
      spacebar.className = "key-pressed";
    }
  });
  
  window.addEventListener("keyup", function (event) {
    if (event.keyCode === 32) {
      spacebar.className = "key";
    }
  });
   