const paragraphs = [
  "impose grasp bet gang venomous background among junk animated dial ruby dome tomatoes bewildered greedy oatmeal same gray appear wheel include numerous nude entertainment ",
  "baboon brothers graveyard beat umbrella handler harness rubber block special between true organization fake stitch enchanting flag rust resemble agenda oceanic subway also curve", 
  "dependent curb creeper bitterness spend gargoyle stew roof rabid bent witness somber story colorful bottom justify abrupt abundant recondite acidic shear skinny curious retreat ", 
  "inlay dexterity salad protect knuckles weigh manage flowery like neurotic bears eat scintillating cynic subtract deprive blended truculent voracious prosecute fried revolt ", 
  "pyramids hover stomach needy greasy being pet hunter interest dogs bald cooing analysis vibrator glass infect fog device sphere engineering glumly band bless bomber failure ",
  "eternity impair distancing heavyweight gangland stink puzzled entropy bury pigeon intruder sawdust deafening hill factual barbarous shrill artist scarify wistful elongation southern serum ",
  "violet armchair diminish pneumatic spike camera fanatic prescribe ill-fated blemish constant succinct ebony pointless caress blankly tragic observe quizzical son ankle betray rastle",
  "story little caramel weed atten autonomous innovate contain apparently front lawyer patience flimsy gratis meek baseline research oafish rings falcon apartment willing kittens  ",
  "blur extreme befall devices gravel championship act crabby rustic net comet ultra saddle disfigurement envious driving afterwards consumer ubiquitous criticism",
  "blindly alcoholic blade blinking wring miserable efficiency jail knuckles ill-informed liver boast lottery turn praise gamy stress extent expensive whales",
  "food plantation road clover crib world debonair milky addict spy escape colony bayonet lucky firecracker dislikable rule noise soul spend boyfriend courage stitch",
  "rage smile earsplitting region box original distort flatness nasty weep robot nightmare achiever degrader bloodstain chase bench ablaze brood silly blouse delicacy exquisite"
];
